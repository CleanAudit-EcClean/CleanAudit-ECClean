# CleanAudit Phase 1

CleanAudit is a standalone hygiene audit platform owned by EC Clean.

This Phase 1 package includes:
- Branded CleanAudit app shell
- Demo admin login
- Protected dashboard state
- Facility-type audit templates
- Custom areas and questions
- Audit scoring
- Corrective actions
- Report preview
- PWA manifest starter

## Demo admin login

This is not connected to a real database yet. Use the demo login button on the sign-in screen.

Suggested demo details:
- Email: admin@cleanaudit.co.za
- Password: password123
- Role: Platform Owner

## Local setup

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

1. Create a GitHub repository called `cleanaudit-phase1`.
2. Upload these files to the repository.
3. Go to Vercel.
4. Click Add New Project.
5. Import the GitHub repository.
6. Click Deploy.
7. Vercel will give you a public URL.

## Phase 2

Connect Supabase for:
- Real authentication
- Organisations
- Users and roles
- Sites and areas
- Audit templates
- Completed audits
- Photo evidence
- Corrective actions
- PDF reports
