import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'CleanAudit',
  description: 'Facility-specific hygiene audits with corrective actions',
  manifest: '/manifest.json',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
